package ru.gb.apiGateAway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGateAwayApplicationTests {

	@Test
	void contextLoads() {
	}

}
